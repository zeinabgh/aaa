import urllib.request
import bs4

url = "http://www.zoomit.ir/2016/11/29/149022/weave-video-editor--android-app/"
html =  urllib.request.urlopen(url)
soup =  bs4.BeautifulSoup(html , "html.parser")

descs = soup.find("div" ,{"class":"article-section"})
desc = descs.find_all('p')
#with open ("D:\\aaaaa\\news1","w") as file:
for d in desc:
       # file.write(str(d))
     print(d.text)

print(soup.title.string)
print(url)
